﻿namespace MethodsLibrary
{
    public struct LatLong
    {
        public double Lat { get; set; }
        public double Long { get; set; }
    }
}